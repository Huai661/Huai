function showMessage(){
    alert("Hello World")
}

document.getElementById("myButton").addEventListener("click",showMessage);